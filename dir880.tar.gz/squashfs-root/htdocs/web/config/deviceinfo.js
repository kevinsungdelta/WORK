//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;
	this.featureSmartConnect = true;
	
	this.helpVer = "";
}
