<? echo "<\?xml version=\"1.0\"?\>"; ?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
	<specVersion>
		<major>1</major>
		<minor>0</minor>
	</specVersion>
	<actionList>
	</actionList>
	<serviceStateTable>
	</serviceStateTable>
</scpd>
