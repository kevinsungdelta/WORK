/**
 * @constructor
 */
function SOAPGetUSB30SettingsResponse()
{
	this.Enabled = "";
};



