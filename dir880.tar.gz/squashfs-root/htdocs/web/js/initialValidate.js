/* Initial Javascript - Validate (Timmy Hsieh)	*/
/* Code Number: 130916							*/
document.write('<script type="text/javascript" charset="utf-8" src="/js/jquery.validate.js"></script>');